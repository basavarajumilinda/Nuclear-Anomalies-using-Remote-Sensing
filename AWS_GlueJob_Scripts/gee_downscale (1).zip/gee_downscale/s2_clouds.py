# s2_clouds.py
import ee
from datetime import datetime

ee.Initialize(project='high-keel-462317-i5')

def make_rectangle(point, buffer_m=2500):
    roi = ee.Geometry.Point(point[0], point[1])
    return roi.buffer(distance=buffer_m).bounds()

def cloudper(image, extent):
    return image.reduceRegion(
        reducer=ee.Reducer.mean(),
        geometry=extent,
        scale=30,
        maxPixels=1e9
    )

def rename(image, new_name):
    return image.select([0], [new_name]).bitwiseAnd(1024).rightShift(10)

def mask_s2_clouds(image):
    qa = image.select('QA60')
    cloudBitMask = 1 << 10
    cirrusBitMask = 1 << 11
    mask = qa.bitwiseAnd(cloudBitMask).eq(0).And(qa.bitwiseAnd(cirrusBitMask).eq(0))
    image = image.updateMask(mask).divide(10000)
    return rename(image, 'Clouds')  # returns a single-band "Clouds" image

def mainS2(point, startdate, enddate, buffer_m=2500, cloud_thresh=0.1):
    """
    point: [lon, lat]
    startdate/enddate: 'YYYY-MM-DD'
    returns: (ee.ImageCollection, [image_ids])
    """
    extent = make_rectangle(point, buffer_m)

    dataset = (ee.ImageCollection('COPERNICUS/S2')
               .filterDate(startdate, enddate)
               .filterBounds(extent)
               .map(mask_s2_clouds))

    L_List = dataset.toList(dataset.size())
    print('S2 dataset size:', dataset.size().getInfo())

    suitable_images = []
    for i in range(dataset.size().getInfo()):
        im = ee.Image(L_List.get(i))
        cloudpercentage = cloudper(im, extent)
        cloud_percent = cloudpercentage.get('Clouds').getInfo()
        if cloud_percent is not None and cloud_percent < cloud_thresh:
            im_id = im.get('system:index').getInfo()
            suitable_images.append(f'COPERNICUS/S2/{im_id}')
    print(suitable_images)

    suitable_images = sorted(suitable_images, key=lambda x: x.split('/')[2])
    final_S2_collection = ee.ImageCollection.fromImages(suitable_images)
    return final_S2_collection, suitable_images, extent
